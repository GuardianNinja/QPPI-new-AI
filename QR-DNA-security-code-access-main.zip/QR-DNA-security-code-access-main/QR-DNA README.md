# QR-DNA Security Layer

This project provides a lineage-safe QR-based security access system.
It is released under the **Seal of Stewardship License 1.0**, combining Apache 2.0 with ethical clauses
to ensure this technology is never weaponized or misused.

Guardians: Space LEAF Corp., Microsoft, Tesla, UN, and Miko.
